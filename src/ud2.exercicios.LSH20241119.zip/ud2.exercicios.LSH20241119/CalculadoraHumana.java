package ud2.practicas;

import java.util.Scanner;


public class CalculadoraHumana {
    public static int preguntar(int operacion, int resultado, boolean primeraPregunta) {        
        System.out.println("Resuelve la siguiente operación:");
        int num1 = 0;
        if (primeraPregunta) {
            num1 = (int) (Math.random() * 100) + 1;
        } else {
            num1 = resultado;
        }
        int num2 = (int) (Math.random() * 100) + 1;

        switch (operacion) {
            case 1:
                System.out.println(num1 + " / " + num2);
                if (num2 == 0) {
                    System.out.println("No dividisible entre cero.");
                } else {
                    resultado = num1 / num2;
                }
                break;
            case 2:
                System.out.println(num1 + " * " + num2);
                resultado = num1 * num2;
                break;
            case 3:
                System.out.println(num1 + " + " + num2);
                resultado = num1 + num2;
                break;
            case 4:
                System.out.println(num1 + " - " + num2);
                resultado = num1 - num2;
                break;
            default:
                break;
        }
        return resultado;
    }

    public static void main(String[] args) {
        final int NUM_MAX_FALLOS = 5;
        final int NUM_OPERACIONES = 7;
        int numAciertos = 0;
        int numFallos = 0;
        int resultado = 0;
        boolean primeraPregunta = true;
        Scanner sc = new Scanner(System.in);
        do {      
            int operacion = (int) (Math.random() * 4) + 1;

            resultado = preguntar(operacion, resultado, primeraPregunta);

            System.out.print("Respuesta: ");
            int respuestaUsuario = sc.nextInt();

            if (respuestaUsuario == resultado) {
                numAciertos++;
                resultado = preguntar(operacion, resultado, !primeraPregunta);
            } else {
                numFallos++;
            }
        } while (numAciertos < NUM_OPERACIONES || numFallos < NUM_MAX_FALLOS);

        System.out.println("El juego ha terminado.");
        sc.close();
    }
}