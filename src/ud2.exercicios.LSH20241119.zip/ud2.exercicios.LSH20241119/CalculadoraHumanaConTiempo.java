import java.util.Random;
import java.util.Scanner;
import java.time.LocalTime;

public class CalculadoraHumanaConTiempo {
    private static final int NUM_OPERACIONES = 7;
    private static final int TIEMPO_LIMITE = 59;
    private static final int MAX_VALOR = 200;
    private static final int MAX_FALLOS = 3;

    private static int fallos = 0;
    private static int operacionesResueltas = 0;
    private static LocalTime tiempoInicio;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        tiempoInicio = LocalTime.now();

        while (operacionesResueltas < NUM_OPERACIONES) {
            if (tiempoAgotado()) {
                System.out.println("¡Tiempo agotado!");
                break;
            }

            int operando1 = generarOperando();
            int operando2;
            char operador = obtenerOperadorAleatorio();

            switch (operador) {
                case '+':
                    operando2 = obtenerOperando2Suma(operando1);
                    break;
                case '-':
                    operando2 = obtenerOperando2Resta(operando1);
                    break;
                case '*':
                    operando2 = obtenerOperando2Multiplicacion(operando1);
                    break;
                case '/':
                    operando2 = obtenerOperando2Division(operando1);
                    break;
                default:
                    continue;
            }

            if (operando2 == -1) {
                System.out.println("No se pudo generar el segundo operando para " + operador);
                continue;
            }

            int resultado = calcularResultado(operando1, operando2, operador);
            System.out.printf("¿Cuánto es %d %c %d? ", operando1, operador, operando2);
            int respuestaUsuario = scanner.nextInt();

            if (respuestaUsuario == resultado) {
                operacionesResueltas++;
                System.out.println("¡Correcto! Has resuelto " + operacionesResueltas + " operaciones.");
            } else {
                fallos++;
                System.out.println("Incorrecto. El resultado era " + resultado + ".");
                if (fallos >= MAX_FALLOS) {
                    System.out.println("Has superado el número de fallos permitidos.");
                    break;
                }
            }
        }

        System.out.println("Fin del juego. Has resuelto " + operacionesResueltas + " operaciones.");
        scanner.close();
    }

    private static boolean tiempoAgotado() {
        LocalTime tiempoFinal = LocalTime.now();
        int segundosTranscurridos = tiempoFinal.toSecondOfDay() - tiempoInicio.toSecondOfDay();
        return segundosTranscurridos >= TIEMPO_LIMITE;
    }

    private static int generarOperando() {
        Random rand = new Random();
        return rand.nextInt(MAX_VALOR) + 1;
    }

    private static char obtenerOperadorAleatorio() {
        Random rand = new Random();
        char[] operadores = {'+', '-', '*', '/'};
        return operadores[rand.nextInt(operadores.length)];
    }

    private static int calcularResultado(int operando1, int operando2, char operador) {
        switch (operador) {
            case '+':
                return operando1 + operando2;
            case '-':
                return operando1 - operando2;
            case '*':
                return operando1 * operando2;
            case '/':
                return operando1 / operando2;
            default:
                return 0;
        }
    }

    static int obtenerOperando2Suma(int operando1) {
        return generarOperando();
    }

    static int obtenerOperando2Resta(int operando1) {
        int operando2 = generarOperando();
        return operando2 < operando1 ? operando2 : -1;
    }

    static int obtenerOperando2Multiplicacion(int operando1) {
        int operando2 = generarOperando();
        return (operando1 * operando2 <= MAX_VALOR) ? operando2 : -1;
    }

    static int obtenerOperando2Division(int operando1) {
        int operando2;
        do {
            operando2 = generarOperando();
        } while (operando2 == 0 || operando1 % operando2 != 0);
        return operando2;
    }
}