package ud2.practicas;

import java.util.InputMismatchException;
import java.util.Scanner;

/*
 * O índice de masa corporal (IMC) é un indicador de saúde que asocia o peso e a altura dunha persoa.
É utilizado, entre outros, pola Organización Mundial da Saúde (OMS), para detectar problemas de
sobrepeso ou malnutrición en adultos. En nenos e adolescentes o IMC calcúlase do mesmo xeito
pero o resultado analízase de xeito distinto segundo a idade e o sexo. (Nota: o IMC é un indicador
moi doado de calcular e útil para clasificar o peso, pero con moitas limitacións, xa que non mide o
grado de grasa corporal nin ten en conta o tipo e forma do corpo de cada persoa)
Calcúlase segundo a operación:
onde a masa se expresa en kilogramos e a estatura en metros.
Implementa unha función coa seguinte declaración que calcule e devolva o IMC dunha persoa a
partir do seu peso e altura, en klos e centimetros respectivamente:
static double imc(double kg, double cm);
Crea un programa que calcule e amose o IMC dunha persoa adulta a partires do seu peso e altura
introducidos por teclado.
O programa deberá validar que os datos introducidos por teclado sexan números correctos:
● o peso introducirase en kg, poderá ter decimais e deberá estar entre 20 e 300 kg
● a altura introducirase como un número enteiro de centímetros, e deberá estar entre 50 e 250.
No caso de introducir letras, símbolos ou números inválidos ofrecerase ao usuario introducir un novo
valor.
O programa deberá amosar o valor calculado e o resultado segundo a seguinte clasificación da OMS.
Clasificación IMC (kg/m²)
Bajo peso <18,50
Normal 18,5 - 24,99
Sobrepeso ≥25,00
Obesidad ≥30,00
 */

public class IMC {

    private static double imc(double kg, double m) {
        double imc = kg/Math.pow(m, 2);
        return imc;
    }

    private static boolean invalidInput(double masa, double altura) {
        if (masa < 20 && masa > 300 && altura < 50 && altura > 250) {
           return false;
        }
        
        return true;
    }

    private static String calcularResultado(double imc) {
        String resultadoIMC = "";

        if (imc < 18.5) {
            resultadoIMC = "Bajo peso";
        } else if (imc >= 18.5 && imc < 25.0) {
            resultadoIMC = "Normal";
        } else if (imc >= 25.0) {
            resultadoIMC = "Sobrepeso";
        } else if (imc >= 30.0) {
            resultadoIMC = "Obesidad";
        }

        return resultadoIMC;
    }

    public static void main(String[] args) {
        double masa = 0;
        double estatura = 0;

        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Introduce la masa de la persona en kilogramos: ");
            masa = sc.nextDouble();
            System.out.print("Introduce la estatura de la persona en metros: ");
            estatura = sc.nextDouble();  
        } catch (InputMismatchException pepito) {
            System.out.print("Introduce de nuevo la masa de la persona en kilogramos: ");
            sc.nextLine();
            masa = sc.nextDouble();
            System.out.print("Introduce de nuevo la estatura de la persona en metros: ");
            sc.nextLine();
            estatura = sc.nextDouble(); 
        }

        while(!invalidInput(masa, estatura*100)) {
            System.out.print("Introduce la masa de la persona en kilogramos: ");
            sc.nextLine();
            masa = sc.nextDouble();
            sc.nextLine();
            System.out.print("Introduce la estatura de la persona en metros: ");
            estatura = sc.nextDouble();  
        }

        sc.close();

        double resultado = imc(masa, estatura);
        String resultadoStr = calcularResultado(resultado);
        System.out.println("Clasificación: "  + resultadoStr);
        System.out.println("Tu IMC es " + resultado);
    }
}
